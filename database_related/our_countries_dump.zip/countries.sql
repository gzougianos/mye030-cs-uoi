/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 80012
Source Host           : localhost:3306
Source Database       : mydb

Target Server Type    : MYSQL
Target Server Version : 80012
File Encoding         : 65001

Date: 2020-06-04 01:50:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `countries`
-- ----------------------------
DROP TABLE IF EXISTS `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(3) NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `income_group` varchar(5000) DEFAULT NULL,
  `special_notes` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of countries
-- ----------------------------
INSERT INTO `countries` VALUES ('1', 'Ghana', 'GHA', 'Sub-Saharan Africa', 'Lower middle income', '');
INSERT INTO `countries` VALUES ('2', 'Gibraltar', 'GIB', 'Europe & Central Asia', 'High income', '');
INSERT INTO `countries` VALUES ('3', 'Greece', 'GRC', 'Europe & Central Asia', 'High income', 'A simple multiplier is used to convert the national currencies of EMU members to euros. The following irrevocable euro conversion rate was adopted by the EU Council on January 1, 1999: 1 euro = 340.75 Greek drachma. Please note that historical data before 1999 are not actual euros and are not comparable or suitable for aggregation across countries.');
INSERT INTO `countries` VALUES ('4', 'Greenland', 'GRL', 'Europe & Central Asia', 'High income', '');
INSERT INTO `countries` VALUES ('5', 'Grenada', 'GRD', 'Latin America & Caribbean', 'Upper middle income', '');
INSERT INTO `countries` VALUES ('6', 'Guam', 'GUM', 'East Asia & Pacific', 'High income', '');
INSERT INTO `countries` VALUES ('7', 'Guatemala', 'GTM', 'Latin America & Caribbean', 'Upper middle income', '');
INSERT INTO `countries` VALUES ('8', 'Guinea', 'GIN', 'Sub-Saharan Africa', 'Low income', '');
INSERT INTO `countries` VALUES ('9', 'Guinea-Bissau', 'GNB', 'Sub-Saharan Africa', 'Low income', '');
INSERT INTO `countries` VALUES ('10', 'Guyana', 'GUY', 'Latin America & Caribbean', 'Upper middle income', '');
INSERT INTO `countries` VALUES ('11', 'Haiti', 'HTI', 'Latin America & Caribbean', 'Low income', 'Fiscal year end: September 30; reporting period for national accounts data: FY.');
INSERT INTO `countries` VALUES ('12', 'Honduras', 'HND', 'Latin America & Caribbean', 'Lower middle income', '');
INSERT INTO `countries` VALUES ('13', 'Hong Kong SAR, China', 'HKG', 'East Asia & Pacific', 'High income', 'On 1 July 1997 China resumed its exercise of sovereignty over Hong Kong. Unless otherwise noted, data for China do not include data for Hong Kong SAR, China; Macao SAR, China; or Taiwan, China. Agriculture value added includes mining and quarrying.');
INSERT INTO `countries` VALUES ('14', 'Hungary', 'HUN', 'Europe & Central Asia', 'High income', '');
INSERT INTO `countries` VALUES ('15', 'Iceland', 'ISL', 'Europe & Central Asia', 'High income', '');
